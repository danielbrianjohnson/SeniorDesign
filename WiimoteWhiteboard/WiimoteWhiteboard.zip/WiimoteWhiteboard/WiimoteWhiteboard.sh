#!/bin/sh
java -jar WiimoteWhiteboard.jar